import 'dart:io';

import 'student.dart';
import 'teacher.dart';

void main() {
  // Welcome message
  print("Welcome to our School Management System!\n");
  // Input Student Data
  print("Please Enter the Student Information:");
  print("Student name:");
  String? studentName = stdin.readLineSync()?? 'Unknown';

  print("Student age:");
  int studentAge = int.tryParse(stdin.readLineSync()!)?? 0;

  print("Student address:");
  String? studentAddress = stdin.readLineSync() ?? 'Did not provide address';

  print("Student ID:");
  String? studentID = stdin.readLineSync() ?? 'Did not provide ID';

  print("Number of courses:");
  int numberOfCourses = int.tryParse(stdin.readLineSync()!)?? 0;

  print("Student scores:");
  List<double> studentScores = [];
  for (int i = 0; i < numberOfCourses; i++) {
    print("Score for course ${i + 1}:");
    double score = double.tryParse(stdin.readLineSync()!) ?? 0.0;
    studentScores.add(score);
  }

  // create instances of Student
  Student student = Student(
    studentName,
    studentAge,
    studentAddress,
    studentID,
    studentScores
  );

  // Display student information
  print("\nStudent Information:");
  print("Name: ${student.getName}");
  student.displayRole();
  print("Age: ${student.getAge}");
  print("Address: ${student.getAddress}");
  print("Average Score: ${student.calculateAverageScore().toStringAsFixed(1)}");

  // Input Teacher Data
  print("\nPlease Enter the Teacher Information:");
  print("Teacher name:");
  String? teacherName = stdin.readLineSync()?? 'Unknown';

  print("Teacher age:");
  int teacherAge = int.tryParse(stdin.readLineSync()!)?? 0;

  print("Teacher address:");
  String? teacherAddress = stdin.readLineSync() ?? 'Did not provide address';

  print("Number of courses taught:");
  int numberOfCoursesTaught = int.tryParse(stdin.readLineSync()!)?? 0;

  print("Courses taught:");
  List<String> coursesTaught = [];
  for (int i = 0; i < numberOfCoursesTaught; i++) {
    print("course name ${i + 1}:");
    String course = (stdin.readLineSync()!) ?? 'Not provided';
    coursesTaught.add(course);
  }

  // create instances of Teacher
  Teacher teacher = Teacher(
    teacherName,
    teacherAge,
    teacherAddress,
    coursesTaught
  );

  // Display teacher information
  print("\nTeacher Information:");
  print("Name: ${teacher.getName}");
  teacher.displayRole();
  print("Age: ${teacher.getAge}");
  print("Address: ${teacher.getAddress}");
  teacher.displayCourses();
}
