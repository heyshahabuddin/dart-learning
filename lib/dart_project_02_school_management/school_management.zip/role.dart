abstract class Role {
  void displayRole();
}